<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "sk_blog");
define("TITLE", "Travel Guide Barishal");
define("KEYWORDS", "CSS, PHP, JAVA, JAVA PROGRAMMING, result");
